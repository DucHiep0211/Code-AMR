
"use strict";

let motor_speed = require('./motor_speed.js')

module.exports = {
  motor_speed: motor_speed,
};
