#!/usr/bin/env python
from math import pi, cos, sin

import diagnostic_msgs
import diagnostic_updater
from roboclaw import Roboclaw
import rospy
import tf
from geometry_msgs.msg import Quaternion, Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64

__author__ = "Hai Nguyen Nhat"

class Node:
    def __init__(self):

        self.ERRORS = {0x0000: (diagnostic_msgs.msg.DiagnosticStatus.OK, "Normal"),
                       0x0001: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "M1 over current"),
                       0x0002: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "M2 over current"),
                       0x0004: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Emergency Stop"),
                       0x0008: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Temperature1"),
                       0x0010: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Temperature2"),
                       0x0020: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Main batt voltage high"),
                       0x0040: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Logic batt voltage high"),
                       0x0080: (diagnostic_msgs.msg.DiagnosticStatus.ERROR, "Logic batt voltage low"),
                       0x0100: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "M1 driver fault"),
                       0x0200: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "M2 driver fault"),
                       0x0400: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "Main batt voltage high"),
                       0x0800: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "Main batt voltage low"),
                       0x1000: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "Temperature1"),
                       0x2000: (diagnostic_msgs.msg.DiagnosticStatus.WARN, "Temperature2"),
                       0x4000: (diagnostic_msgs.msg.DiagnosticStatus.OK, "M1 home"),
                       0x8000: (diagnostic_msgs.msg.DiagnosticStatus.OK, "M2 home")}

        rospy.init_node("robot_driver")
        rospy.loginfo("Connecting to roboclaw")

        front_dev_name = rospy.get_param("~front_dev", "/dev/ttyACM0")
        front_baud_rate = int(rospy.get_param("~front_baud", "115200"))
        self.front_address = int(rospy.get_param("~front_address", "130"))

        rear_dev_name = rospy.get_param("~rear_dev", "/dev/ttyACM1")
        rear_baud_rate = int(rospy.get_param("~rear_baud", "115200"))
        self.rear_address = int(rospy.get_param("~rear_address", "129"))

        
        self.front_rc = Roboclaw(front_dev_name, front_baud_rate)
        self.rear_rc = Roboclaw(rear_dev_name, rear_baud_rate)

        self.last_enc_time = rospy.Time.now()

        self.front_old_enc_01 = 0
        self.front_old_enc_02 = 0
        
        self.rear_old_enc_01 = 0
        self.rear_old_enc_02 = 0

        self.position_x = 0.0
        self.position_y = 0.0
        self.angular_z = 0.0

        self.cmd_linear_x = 0.0
        self.cmd_angular_z = 0.0

        if self.rear_address > 0x87 or self.rear_address < 0x80:
            rospy.logfatal("Rear_Address out of range")
            rospy.signal_shutdown("Rear_Address out of range")
        if self.front_address > 0x87 or self.front_address < 0x80:
            rospy.logfatal("Rear_Address out of range")
            rospy.signal_shutdown("Rear_Address out of range")


        try:
            self.front_rc.Open()
        except Exception as e:
            rospy.logfatal("Could not connect to Roboclaw")
            rospy.logdebug(e)
            rospy.signal_shutdown("Could not connect to Roboclaw")

        try:
            self.rear_rc.Open()
        except Exception as e:
            rospy.logfatal("Could not connect to Roboclaw")
            rospy.logdebug(e)
            rospy.signal_shutdown("Could not connect to Roboclaw")     
        try:
            self.front_rc.SetM1VelocityPID(self.front_address,2.26285, 0.37085, 0.0,8812)
            self.front_rc.SetM2VelocityPID(self.front_address,2.12448, 0.42783, 0.0,8437)
            # self.front_rc.SetM1MaxCurrent(self.front_address,2.0)
            # self.front_rc.SetM2MaxCurrent(self.front_address,2.0)

            self.rear_rc.SetM1VelocityPID(self.rear_address, 2.35532, 0.37509, 0.0,9000)
            self.rear_rc.SetM2VelocityPID(self.rear_address, 2.52843, 0.42257, 0.0,7312)
            # self.rear_rc.SetM1MaxCurrent(self.rear_address,2.0)
            # self.rear_rc.SetM2MaxCurrent(self.rear_address,2.0)


            self.front_rc.SpeedM1M2(self.front_address,0,0)
            self.front_rc.ResetEncoders(self.front_address)

            self.rear_rc.SpeedM1M2(self.rear_address,0,0)
            self.rear_rc.ResetEncoders(self.rear_address)
        except Exception as e:
            rospy.logfatal("cdasdasdsdw")


        self.MAX_SPEED = float(rospy.get_param("~max_speed", "2.0"))
        self.TICKS_PER_METER = float(rospy.get_param("~tick_per_meter", "3233.7089"))
        self.BASE_WIDTH = float(rospy.get_param("~base_width", "0.32"))
        self.BASE_LENGHT = float(rospy.get_param("~base_lenght", "0.24"))

        rospy.Subscriber("cmd_vel", Twist, self.cmd_vel_callback)
        #rospy.Subscriber("/odometry/filtered", Odometry, self.odom_fillter_callback)    
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=10)
        self.pub_z = rospy.Publisher('/rotate_z', Float64, queue_size=10)
        self.odom_broadcaster = tf.TransformBroadcaster()

    def run(self):
        rospy.loginfo("Starting motor drive")
        r_time = rospy.Rate(10)
        front_enc_01 = 0
        front_enc_02 = 0 
        rear_enc_01 = 0
        rear_enc_02 = 0
        linear_x = 0.0
        rotate_z = 0.0
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()
            # status_fr = self.front_rc.ReadError(self.front_address)[1]
            # status_rr = self.rear_rc.ReadError(self.rear_address)[1]
            # state_fr, message_fr = self.ERRORS[status_fr]
            # state_rr, message_rr = self.ERRORS[status_rr]
            # print("front msg: ", message_fr)
            # print("rear msg: ", message_rr)
            
            vr = self.cmd_linear_x + self.cmd_angular_z * self.BASE_WIDTH / 2.0  # m/s
            vl = self.cmd_linear_x -  self.cmd_angular_z* self.BASE_WIDTH / 2.0

            vr_ticks = int((vr / (3.14*0.10)) * 1320) # 1 vong encode /11 xung * 30 *4
            vl_ticks = int((vl / (3.14*0.10)) * 1320)

            try:
                # This is a hack way to keep a poorly tuned PID from making noise at speed 0
                if vr_ticks is 0 and vl_ticks is 0:
                    self.front_rc.SpeedM1M2(self.front_address,0,0)
                    self.rear_rc.SpeedM1M2(self.rear_address,0,0)
                else:
                    self.front_rc.SpeedM1M2(self.front_address,vl_ticks,vr_ticks) # M1 M2
                    self.rear_rc.SpeedM1M2(self.rear_address,vr_ticks,vl_ticks)
            except OSError as e:
                rospy.logwarn("SpeedM1M2 OSError: %d", e.errno)
                rospy.logdebug(e)
            
            front_enc_left = self.front_rc.ReadEncM1(self.front_address)[1]
            front_enc_right = self.front_rc.ReadEncM2(self.front_address)[1]

            rear_enc_left = self.rear_rc.ReadEncM2(self.rear_address)[1]
            rear_enc_right = self.rear_rc.ReadEncM1(self.rear_address)[1]

            front_enc_left_new = front_enc_left - self.front_old_enc_01
            front_enc_right_new = front_enc_right - self.front_old_enc_02

            rear_enc_left_new = rear_enc_left - self.rear_old_enc_01
            rear_enc_right_new = rear_enc_right - self.rear_old_enc_02

            print("enc left: " ,((front_enc_left_new + rear_enc_left_new)/2))
            print("enc right: " ,((front_enc_right_new + rear_enc_right_new)/2))

            front_d_01 = 0.1 * 3.14 * (front_enc_left_new / 1320.0)
            front_d_02 = 0.1 * 3.14 * (front_enc_right_new / 1320.0)
            rear_d_01 = 0.1 * 3.14 * (rear_enc_left_new / 1320.0)
            rear_d_02 = 0.1 * 3.14 * (rear_enc_right_new / 1320.0)

            d_left = (front_d_01 + rear_d_01)/2.0
            d_right = (front_d_02 + rear_d_02)/2.0

            d_x = (d_left + d_right) / 2.0
            d_z = (d_right - d_left) / (self.BASE_WIDTH)

            
            d_time = (current_time - self.last_enc_time).to_sec()
            self.last_enc_time = current_time
            #print("time :::: ",d_time)

            #if d_time > 0.01:
            linear_x = d_x / d_time
            rotate_z = d_z / d_time

            self.angular_z = self.angular_z + d_z

            dx=d_x * cos(self.angular_z)
            dy=d_x * sin(self.angular_z)

            self.position_x = self.position_x + dx
            self.position_y = self.position_y + dy
            
            if self.angular_z >= 6.28:
                self.angular_z = self.angular_z - 6.28
            if self.angular_z <= - 6.28:
                self.angular_z = self.angular_z + 6.28
            #print("angular_z :::: ", self.angular_z)
            
            self.pub_tf_odom(self.position_x,self.position_y, self.angle_z)

            self.front_old_enc_01 = front_enc_left
            self.front_old_enc_02 = front_enc_right

            self.rear_old_enc_01 = rear_enc_left
            self.rear_old_enc_02 = rear_enc_right
            
            self.odom_pub_CB(linear_x,rotate_z)

            r_time.sleep()

        
    def odom_pub_CB(self,linear_x,rotate_z):

        odom_quat = Quaternion()
        odom_quat = tf.transformations.quaternion_from_euler(0,0,self.angular_z)
        a = Float64()
        a.data=self.angular_z /3.14 * 180.0
        self.pub_z.publish(a)
        #rospy.loginfo(self.angular_z)
        odom_msg = Odometry()
        odom_msg.header.stamp = rospy.Time.now()
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_footprint'

        odom_msg.pose.pose.position.x = self.position_x
        odom_msg.pose.pose.position.y = self.position_y
        odom_msg.pose.pose.position.z = 0.0
        # odom_msg.pose.pose.orientation = odom_quat
        odom_msg.pose.pose.orientation.z = odom_quat[2]
        odom_msg.pose.pose.orientation.w = odom_quat[3]

        odom_msg.pose.covariance[0]= 0.01
        odom_msg.pose.covariance[7]= 0.01
        odom_msg.pose.covariance[14]= 1e-12
        odom_msg.pose.covariance[21]= 1e-12
        odom_msg.pose.covariance[28]= 1e-12
        odom_msg.pose.covariance[35]= 0.01
        
        odom_msg.twist.twist.linear.x = linear_x
        odom_msg.twist.twist.angular.z = rotate_z
        odom_msg.twist.covariance[0]= 0.01
        odom_msg.twist.covariance[7]= 1e-12
        odom_msg.twist.covariance[14]= 1e-12
        odom_msg.twist.covariance[21]= 1e-12
        odom_msg.twist.covariance[28]= 1e-12
        odom_msg.twist.covariance[35]= 0.01

        # self.odom_broadcaster.sendTransform(
        # (self.position_x, self.position_y, 0.0),
        # odom_quat,
        # rospy.Time.now(),
        # "base_footprint",
        # "odom")

        # print odom_msg
        self.odom_pub.publish(odom_msg)
        
    def cmd_vel_callback(self, twist):

        self.cmd_linear_x = twist.linear.x
        self.cmd_angular_z = twist.angular.z
    
    def pub_tf_odom(self,pose_x,pose_y,rotate_z):
        
        odom_quat = tf.transformations.quaternion_from_euler(0, 0, rotate_z)

        # first, we'll publish the transform over tf
        self.odom_broadcaster.sendTransform(
            (pose_x, pose_y, 0.),
            odom_quat,
            rospy.Time.now(),
            "base_footprint",
            "odom"
        )
            


if __name__ == "__main__":
    try:
        node = Node()
        node.run()
    except rospy.ROSInterruptException:
        pass
    rospy.loginfo("Exiting")