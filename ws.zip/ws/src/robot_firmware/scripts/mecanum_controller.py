#!/usr/bin/env python3
import rospy
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Quaternion, Twist
import math
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64 , Float64MultiArray

import tf


# lineare maxx : 0.08
# 	min 0.015
# angular z max 0.5
# 	min 0.15
class Node:
    def __init__(self):
        rospy.init_node("robot_firmware")

        rospy.Subscriber("pose_encod",Int32MultiArray,self.pose_encod_cb)
        rospy.Subscriber("delta_enc",Int32MultiArray,self.delta_encod_cb)
        rospy.Subscriber("cmd_vel",Twist,self.cmd_vel_cb)

        self.duty_pub = rospy.Publisher("duty_motor",Int32MultiArray,queue_size=10)
        self.target = rospy.Publisher("vel_target",Float64MultiArray,queue_size=10)
        self.real = rospy.Publisher("vel_real",Float64MultiArray,queue_size=10)
        self.direct_pub = rospy.Publisher("direct_motor",Int32MultiArray,queue_size=10)
        self.pub_z = rospy.Publisher('/rotate_z', Float64, queue_size=10)
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=10)
        self.odom_broadcaster = tf.TransformBroadcaster()

        self.last_enc_time = rospy.Time.now()


        # front_left, front_right , rear_left, rear_right
        
        self.pose_ecoder_data_now = [0 , 0, 0, 0]
        self.pose_ecoder_data_prev = [0 , 0, 0, 0]
        self.delta_ecoder_data = [0.0 , 0.0, 0.0, 0.0]
        self.vel_wheel_target = [0.0 , 0.0, 0.0, 0.0]
        # self.vel_wheel_real = [0.0 , 0.0, 0.0, 0.0]

        self.delta_travel_wheel= [0.0 , 0.0, 0.0, 0.0]
        self.vel_wheel_real= [0.0 , 0.0, 0.0, 0.0]



        # Error 
        self.error_now = [0.0 , 0.0, 0.0, 0.0]
        self.error_last = [0.0 , 0.0, 0.0, 0.0]
        self.error_last_last = [0.0 , 0.0, 0.0, 0.0]
        self.error_all =[0.0 , 0.0, 0.0, 0.0]

        self.twist_target = Twist()



        # PID Params
        self.kp = [18.5, 17.7, 18.2, 17.5]
        self.ki = [9.2 , 9.2, 8.9, 8.5]
        self.kd = [0.095, 0.095, 0.089, 0.096]



        # Dimension of robot 
        self.wheelSeparation =  0.11
        self.wheelSeparationLength = 0.08
        self.diameter_wheel = 0.08
        self.ticks_per_round = 990  #330 / 3.14 *0.08 11*30
        self.ticks_per_metter = 330 / 3.14 / 0.08

        self.pi_ = 3.14159


        # pose of robot 
        self.position_x = 0.0
        self.position_y = 0.0
        self.angle_z = 0.0

        # Vel of robot
        self.linear_x = 0.0
        self.linear_y = 0.0
        self.angular_z = 0.0

        # Duty  

        self.duty_data = [0.0, 0.0, 0.0, 0.0]
        self.direct_data =[0.0 , 0.0, 0.0, 0.0]

        self.duty_data_pub = Int32MultiArray()
        self.direct_data_pub = Int32MultiArray()
        
        
        # left_ticks_meter = 1.0 / (pi_*diameter_wheel) * float (left_ticks_round);
        # right_ticks_meter = 1.0 / (pi_*diameter_wheel) * float (right_ticks_round);

        self.ticks_per_metter  = 1.0 / (self.pi_ * self.diameter_wheel) * self.ticks_per_round

    def cmd_vel_cb(self,msg):

        self.twist_target = msg
        # print(twist_target)
        
    def pose_encod_cb(self,msg):
        # print(msg)
        self.pose_ecoder_data_now = msg.data

    def delta_encod_cb(self,msg):
        self.delta_encod_data  = msg.data
        self.pose_right_now_encod = msg.data[0]
        self.pose_left_now_encod = msg.data[1]

    def run(self):

        r_time = rospy.Rate(25)


        # linear_x = 0.0 
        # linear_y = 0.0
        # angular_z = 0.0

        while not rospy.is_shutdown():
            
            linear_x = self.twist_target.linear.x
            linear_y = self.twist_target.linear.y 
            angular_z = self.twist_target.angular.z

            # print(self.ticks_per_metter * (linear_x - linear_y - (self.wheelSeparation + self.wheelSeparationLength)*angular_z))
            # print(linear_x)
            # print( self.twist_target.linear.x) self.ticks_per_metter *

            # don vi rad /s 
            self.vel_wheel_target[0] =  (linear_x - linear_y - (self.wheelSeparation + self.wheelSeparationLength)*angular_z)
            self.vel_wheel_target[1] =  (linear_x + linear_y + (self.wheelSeparation + self.wheelSeparationLength)*angular_z)
            self.vel_wheel_target[2] =  (linear_x + linear_y - (self.wheelSeparation + self.wheelSeparationLength)*angular_z)
            self.vel_wheel_target[3] = (linear_x - linear_y + (self.wheelSeparation + self.wheelSeparationLength)*angular_z)
            
            print(" Vel wheels target : " ,self.vel_wheel_target)

            self.delta_ecoder_data[0]= self.pose_ecoder_data_now[0] - self.pose_ecoder_data_prev[0]
            self.delta_ecoder_data[1]= self.pose_ecoder_data_now[1] - self.pose_ecoder_data_prev[1]
            self.delta_ecoder_data[2]= self.pose_ecoder_data_now[2] - self.pose_ecoder_data_prev[2]
            self.delta_ecoder_data[3]= self.pose_ecoder_data_now[3] - self.pose_ecoder_data_prev[3]
            

            self.pose_ecoder_data_prev[0] = self.pose_ecoder_data_now[0]
            self.pose_ecoder_data_prev[1] = self.pose_ecoder_data_now[1]
            self.pose_ecoder_data_prev[2] = self.pose_ecoder_data_now[2]
            self.pose_ecoder_data_prev[3] = self.pose_ecoder_data_now[3]
            # print("Delta encoder Dat : " , self.delta_ecoder_data)

            self.delta_travel_wheel[0] = self.delta_ecoder_data[0] / self.ticks_per_metter # m/s
            self.delta_travel_wheel[1] = self.delta_ecoder_data[1] / self.ticks_per_metter
            self.delta_travel_wheel[2] = self.delta_ecoder_data[2] / self.ticks_per_metter
            self.delta_travel_wheel[3] = self.delta_ecoder_data[3] / self.ticks_per_metter
            # print("Delta travel wheel : ", self.delta_travel_wheel)

            current_time = rospy.Time.now()
            delta_t = (current_time - self.last_enc_time).to_sec()
            self.last_enc_time = current_time

            self.vel_wheel_real[0] = self.delta_travel_wheel[0] / delta_t
            self.vel_wheel_real[1] = self.delta_travel_wheel[1] / delta_t
            self.vel_wheel_real[2] = self.delta_travel_wheel[2] / delta_t
            self.vel_wheel_real[3] = self.delta_travel_wheel[3] / delta_t
            print("Velocity of   wheel  real : ", self.delta_travel_wheel)
            
            # Delta Origin of Robot 
            travel_x = (self.delta_travel_wheel[0] + self.delta_travel_wheel[1] + self.delta_travel_wheel[2]+ self.delta_travel_wheel[3]) / 4.0
            travel_y = (- self.delta_travel_wheel[0] + self.delta_travel_wheel[1] + self.delta_travel_wheel[2] - self.delta_travel_wheel[3]) / 4.0
            travel_theta = (-self.delta_travel_wheel[0] + self.delta_travel_wheel[1] - self.delta_travel_wheel[2]+ self.delta_travel_wheel[3]) / (4.0 * (self.wheelSeparation + self.wheelSeparationLength))

            # vel of robot 

            vel_x = travel_x / delta_t
            vel_y = travel_y /delta_t
            vel_theta = travel_theta/delta_t
            
            self.angle_z = self.angle_z + travel_theta
            if self.angle_z >= 6.28:
                self.angle_z = self.angle_z - 6.28
            if self.angle_z <= - 6.28:
                self.angle_z = self.angle_z + 6.28

            delta_x = travel_x* math.cos(self.angle_z) - travel_y * math.sin(self.angle_z) 
            delta_y = travel_y* math.cos(self.angle_z) + travel_x* math.sin(self.angle_z) 

            self.position_x = self.position_x + delta_x
            self.position_y = self.position_y + delta_y
            # self.pose.x += deltaXTravel*cos(self.pose.theta) - deltaYTravel*sin(self.pose.theta)
            # self.pose.y += deltaYTravel*cos(self.pose.theta) + deltaXTravel*sin(self.pose.theta)
            # theta = (self.pose.theta + deltaTheta) % (2*pi)
            
            self.calculate_PID(0,self.vel_wheel_target[0],self.vel_wheel_real[0],delta_t)
            self.calculate_PID(1,self.vel_wheel_target[1],self.vel_wheel_real[1],delta_t)
            self.calculate_PID(2,self.vel_wheel_target[2],self.vel_wheel_real[2],delta_t)
            self.calculate_PID(3,self.vel_wheel_target[3],self.vel_wheel_real[3],delta_t)
            
            print ("=======================")
            print("error now ",self.error_now)
            duty_array = Int32MultiArray()
            direct_array = Int32MultiArray()

            target_array = Float64MultiArray()
            real_array = Float64MultiArray()

            direct_array.data = [int(self.duty_data[0]),int(self.duty_data[1]),
                                int(self.duty_data[2]),int(self.duty_data[3])]
            

            duty_array.data =  [int(abs(self.duty_data[0])),int(abs(self.duty_data[1])),
                                int(abs(self.duty_data[2])),int(abs(self.duty_data[3]))]
            
            # print("duty arrrayyyy : ",)
            target_array.data = [(self.vel_wheel_target[0]),(self.vel_wheel_target[1]),
                                (self.vel_wheel_target[2]),(self.vel_wheel_target[3])]
            

            real_array.data =  [((self.vel_wheel_real[0])),((self.vel_wheel_real[1])),
                                ((self.vel_wheel_real[2])),((self.vel_wheel_real[3]))]

            
            self.direct_pub.publish(direct_array)
            self.duty_pub.publish(duty_array)

            self.target.publish(target_array)
            self.real.publish(real_array)


            self.odom_pub_CB(vel_x,vel_y,vel_theta)
            self.pub_tf_odom(self.position_x,self.position_y , self.angle_z)

            r_time.sleep()

    def calculate_PID(self,stt,vel_target, vel_real,delta_time):

        self.error_last_last[stt]  = self.error_last[stt]
        self.error_last[stt] = self.error_now[stt]
        self.error_now[stt] = vel_target - vel_real

        P_ = self.kp[stt] *( self.error_now[stt]);
        I_ = 0.5 *self.ki[stt]  * delta_time *( self.error_now[stt] + self.error_last[stt])
        D_ = self.kd[stt] / delta_time * (self.error_now[stt] - 2*self.error_last[stt] +self.error_last_last[stt]);
        
        self.duty_data[stt] = self.duty_data[stt] + P_ + I_ + D_

        if (self.duty_data[stt] > 100.0) : 
            self.duty_data[stt] = 100

        if (self.duty_data[stt] < -100.0) :
            self.duty_data[stt] = -100
        
        if (vel_target == 0.0):
            self.duty_data[stt] = 0
    
    def left_motor_PID():

        ### PID Left motor
        self.error_left_last_last = self.error_left_last;
        self.error_left_last =  self.error_left_now;
        self.error_left_now = (vel_left_enc -rpm_left );  # Target - reals
        self.error_left_all = self.error_left_all + self.error_left_now;

        P_l = Kp_l *( self.error_left_now);
        I_l = 0.5 *Ki_l *t *(self.error_left_now + self.error_left_last)
        D_l = Kd_l/t * (self.error_left_now - 2*self.error_left_last +self.error_left_last_last);
        
        self.duty_left = self.duty_left + P_l + I_l + D_l

        left = int (abs( self.duty_left))
            
        if (left > 250) : 
            left = 250
            #self.duty_left = 250.0
        if (left < 0) :
            left = 0
            #self.duty_left = 0.0

        print("self.duty_left  :",self.duty_left , self.error_left_now  )
    
    def right_motor_PID():
        ### PID Left motor
        self.error_right_last_last = self.error_right_last;
        self.error_right_last =  self.error_right_now;
        self.error_right_now =(vel_right_enc - rpm_right) ;  # Target - reals
        self.error_right_all = self.error_right_all + self.error_right_now;

        P_r = Kp_l *( self.error_right_now);
        I_r = 0.5 *Ki_l *t *(self.error_right_now + self.error_right_last)
        D_r = Kd_l/t * (self.error_right_now - 2*self.error_right_last +self.error_right_last_last);
        
        self.duty_right = self.duty_right + P_r + I_r + D_r
        
        right = int (abs (self.duty_right))


        if (right > 250) : 
            right = 250
            #self.duty_right = 250.0
        if (right < 0) :
            right = 0
            #self.duty_right = 0.0


        if (self.linear_x == 0.0 and self.angular_z == 0.0):
            self.duty_left = 0
            self.duty_right = 0
        print("self.duty_right  :",self.duty_right, self.error_right_now)



    def odom_pub_CB(self,linear_x,linear_y,rotate_z):

        odom_quat = Quaternion()
        odom_quat = tf.transformations.quaternion_from_euler(0,0,self.angle_z)
        a = Float64()
        a.data=self.angle_z /3.14 * 180.0
        self.pub_z.publish(a)

        rospy.loginfo(self.angle_z)

        odom_msg = Odometry()
        odom_msg.header.stamp = rospy.Time.now()
        odom_msg.header.frame_id = 'odom'
        odom_msg.child_frame_id = 'base_footprint'

        odom_msg.pose.pose.position.x = self.position_x
        odom_msg.pose.pose.position.y = self.position_y
        odom_msg.pose.pose.position.z = 0.0
        # odom_msg.pose.pose.orientation = odom_quat

        odom_msg.pose.pose.orientation.x = 0.0
        odom_msg.pose.pose.orientation.y = 0.0
        odom_msg.pose.pose.orientation.z = odom_quat[2]
        odom_msg.pose.pose.orientation.w = odom_quat[3]

        odom_msg.pose.covariance[0]= 0.01
        odom_msg.pose.covariance[7]= 0.01
        odom_msg.pose.covariance[14]= 1e-12
        odom_msg.pose.covariance[21]= 1e-12
        odom_msg.pose.covariance[28]= 1e-12
        odom_msg.pose.covariance[35]= 0.01
        
        odom_msg.twist.twist.linear.x = linear_x
        odom_msg.twist.twist.linear.x = linear_y
        odom_msg.twist.twist.angular.z = rotate_z

        odom_msg.twist.covariance[0]= 0.01
        odom_msg.twist.covariance[7]= 1e-12
        odom_msg.twist.covariance[14]= 1e-12
        odom_msg.twist.covariance[21]= 1e-12
        odom_msg.twist.covariance[28]= 1e-12
        odom_msg.twist.covariance[35]= 0.01

        # print odom_msg
        self.odom_pub.publish(odom_msg)
        
    def pub_tf_odom(self,pose_x,pose_y,rotate_z):
        
        odom_quat = tf.transformations.quaternion_from_euler(0, 0, rotate_z)

        # first, we'll publish the transform over tf
        self.odom_broadcaster.sendTransform(
            (pose_x, pose_y, 0.),
            odom_quat,
            rospy.Time.now(),
            "base_footprint",
            "odom"
        )
if __name__ == "__main__":
    try:
        node = Node()
        node.run()
    except rospy.ROSInterruptException:
        pass
    rospy.loginfo("Exiting")











